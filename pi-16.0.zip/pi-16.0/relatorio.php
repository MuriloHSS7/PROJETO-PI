<?php
require 'conexao.php';
session_start();

if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit;
}

echo "<h2>Relatório de Vendas</h2>";

// Consulta para buscar todas as vendas realizadas
$stmt = $pdo->query("SELECT v.id, u.nome AS usuario, p.nome AS produto, v.quantidade, v.total, 
                     v.forma_pagamento, v.data_venda 
                     FROM vendas v
                     JOIN usuarios u ON v.usuario_id = u.id
                     JOIN produtos p ON v.produto_id = p.id");

$vendas = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (count($vendas) > 0) {
    // Exibir os dados de uma forma amigável em uma tabela
    echo "<table border='1' cellspacing='0' cellpadding='10'>
            <thead>
                <tr>
                    <th>ID da Venda</th>
                    <th>Usuário</th>
                    <th>Produto</th>
                    <th>Quantidade</th>
                    <th>Total (R$)</th>
                    <th>Forma de Pagamento</th>
                    <th>Data da Venda</th>
                </tr>
            </thead>
            <tbody>";
    
    foreach ($vendas as $venda) {
        echo "<tr>
                <td>" . $venda['id'] . "</td>
                <td>" . htmlspecialchars($venda['usuario']) . "</td>
                <td>" . htmlspecialchars($venda['produto']) . "</td>
                <td>" . $venda['quantidade'] . "</td>
                <td>" . number_format($venda['total'], 2, ',', '.') . "</td>
                <td>" . htmlspecialchars($venda['forma_pagamento']) . "</td>
                <td>" . $venda['data_venda'] . "</td>
              </tr>";
    }

    echo "</tbody></table>";
} else {
    echo "Nenhuma venda foi encontrada.";
}

echo '<button onclick="window.print()">Imprimir Relatório</button>';

echo '<br><a href="dashboard_funcionario.php">Voltar para o perfil</a>';
?>
