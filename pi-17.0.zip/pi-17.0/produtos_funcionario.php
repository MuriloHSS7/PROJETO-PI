<?php
session_start();

if (!isset($_SESSION['usuario_id']) || $_SESSION['tipo'] != 'cliente') {
   header("Location: login.php");
   exit;
}

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
   <!-- basic -->
   <meta charset="utf-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <!-- mobile metas -->
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <meta name="viewport" content="initial-scale=1, maximum-scale=1">
   <!-- site metas -->
   <title>Nossos produtos</title>
   <meta name="keywords" content="">
   <meta name="description" content="">
   <meta name="author" content="">
   <!-- bootstrap css -->
   <link rel="stylesheet" href="css/bootstrap.min.css">
   <!-- style css -->
   <link rel="stylesheet" href="css/style.css">
   <style>
      .profile-pic {
         width: 40px;
         height: 40px;
         border-radius: 50%;
         object-fit: cover;
         margin-left: 10px;
      }
   </style>
   <!-- Responsive-->
   <link rel="stylesheet" href="css/responsive.css">
   <!-- fevicon -->
   <link rel="icon" href="images/fevicon.png" type="image/gif" />
   <!-- Scrollbar Custom CSS -->
   <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
   <!-- Tweaks for older IEs-->
   <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css"
      media="screen">
   <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
</head>

<body class="main-layout position_head">
   <div class="loader_bg">
      <div class="loader"><img src="images/loading.gif" alt="Carregamento da página" /></div>
   </div>
   <header>
      <div class="header">
         <div class="container-fluid">
            <div class="row">
               <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col logo_section">
                  <div class="full">
                     <div class="center-desk">
                        <div class="logo">
                           <a href="inicial_cliente.php"><img src="images/logo.jpg" alt="Logo da loja TI Games" /></a>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-xl-9 col-lg-9 col-md-9 col-sm-9">
                  <nav class="navigation navbar navbar-expand-md navbar-dark ">
                     <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample04"
                        aria-controls="navbarsExample04" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                     </button>
                     <div class="collapse navbar-collapse" id="navbarsExample04">
                        <ul class="navbar-nav mr-auto">
                           <li class="nav-item ">
                              <a class="nav-link" href="inicial_cliente.php">Início</a>
                           </li>
                           <li class="nav-item">
                              <a class="nav-link" href="sobre_cliente.php">Sobre nós</a>
                           </li>
                           <li class="nav-item">
                              <a class="nav-link" href="produtos.php">Nossos produtos</a>
                           </li>
                           <li class="nav-item">
                              <a class="nav-link" href="loja_cliente.php">Loja</a>
                           </li>
                           <li class="nav-item d_none login_btn">
                              <a class="nav-link" href="logout.php">Sair</a>
                           </li>
                        </ul>
                        <a href="dashboard_cliente.php"><img src="images/garotagamer1.jpg" alt="foto de perfil" class="profile-pic"></a>
                        <a href="carrinho.php"><img src="images/Carrinho de compra.png" alt="imagem do carrinho de compra" class="profile-pic"></a>
                     </div>
                  </nav>
               </div>
            </div>
         </div>
      </div>
   </header>
   <div class="glasses">
      <div class="container">
         <div class="row">
            <div class="col-md-10 offset-md-1">
               <div class="titlepage">
                  <h2>Descubra um mundo de diversão:</h2>
                  <p>Aqui você encontra todos os jogos, desde os clássicos atemporais até os mais inovadores da nova
                     geração!</p>
               </div>
            </div>
         </div>
      </div>
      <div class="playxboxperi">
         <div class="buttonnn">
            <a class="playstation" href="produtosplays_cliente.php">PlayStation</a>
         </div>
         <div class="buttonnn">
            <a class="xbox" href="produtosXbox_cliente.php">Xbox</a>
         </div>
         <div class="buttonnn">
            <a class="perifericos" href="produtosPerifericos_cliente.php">Perifericos</a>
         </div>
      </div>
      <div class="container-fluid">
         <div class="row">
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
               <div class="glasses_box">
                  <figure><img src="jogosplay/assassinoscreedJOGO.jpg" alt="jogo dos assassin's Creed" /></figure>
                  <h3><span class="blu">R$</span> 139,99</h3>
                  <p>Assassin's Creed Mirage - playstation 5</p>
                  <h2 class="read_more">Disponível</h2>
               </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
               <div class="glasses_box">
                  <figure><img src="jogosxbox/avengers.jpg" alt="jogo os vingadores" /></figure>
                  <h3><span class="blu">R$</span> 89,99</h3>
                  <p>Marvel's Avengers - Xbox One</p>
                  <h2 class="read_more">Disponível</h2>
               </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
               <div class="glasses_box">
                  <figure><img src="jogosplay/astrobot.jpg" alt="jogo astro bot" /></figure>
                  <h3><span class="blu">R$</span> 189,99</h3>
                  <p>Astro bot - PlayStation 5</p>
                  <h2 class="read_more">Disponível</h2>
               </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
               <div class="glasses_box">
                  <figure><img src="jogosxbox/batman.jpg" alt="jogo batman" /></figure>
                  <h3><span class="blu">R$</span> 49,99</h3>
                  <p>batman return to arkham - xbox one</p>
                  <h2 class="read_more">Disponível</h2>
               </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
               <div class="glasses_box">
                  <figure><img src="jogosplay/eldenring.jpg" alt="jogo elden ring" /></figure>
                  <h3><span class="blu">R$</span> 249,99</h3>
                  <p>Elden ring - playstation 5</p>
                  <h2 class="read_more">Disponível</h2>
               </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
               <div class="glasses_box">
                  <figure><img src="jogosxbox/battlefield1.jpg" alt="jogo batlefield 1" /></figure>
                  <h3><span class="blu">R$</span> 129,99</h3>
                  <p>batlefield 1 revolution - xbox one</p>
                  <h2 class="read_more">Disponível</h2>
               </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
               <div class="glasses_box">
                  <figure><img src="jogosplay/farcry6.jpg" alt="jogo far cry 6" /></figure>
                  <h3><span class="blu">R$</span> 149,99</h3>
                  <p>Far Cry 6 - playstation 5</p>
                  <h2 class="read_more">Disponível</h2>
               </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
               <div class="glasses_box">
                  <figure><img src="jogosxbox/bully.jpg" alt="jogo bully" /></figure>
                  <h3><span class="blu">R$</span> 179,99</h3>
                  <p>Bully: Edição de Bolsas de Estudo (xbox-one) - Xbox-360</p>
                  <h2 class="read_more">Disponível</h2>
               </div>
            </div>
            <!--Periféricos-->
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
               <div class="glasses_box">
                  <figure><img src="jogosplay/FC24.jpg" alt="jogo fifa 24" /></figure>
                  <h3><span class="blu">R$</span> 159,99</h3>
                  <p>EA Sports Fc 24 - playstation 5</p>
                  <h2 class="read_more">Disponível</h2>
               </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
               <div class="glasses_box">
                  <figure><img src="jogosxbox/cyberpunk.jpg" alt="jogo cyberpunk 2077 " /></figure>
                  <h3><span class="blu">R$</span> 109,99</h3>
                  <p>Cyberpunk 2077 - xbox one</p>
                  <h2 class="read_more">Disponível</h2>
               </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
               <div class="glasses_box">
                  <figure><img src="jogosplay/FC25.jpg" alt="jogo fifa 25" /></figure>
                  <h3><span class="blu">R$</span> 289,99</h3>
                  <p>EA Sports Fc 25 - playstation 5</p>
                  <h2 class="read_more">Disponível</h2>
               </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
               <div class="glasses_box">
                  <figure><img src="jogosxbox/deusex.jpg" alt="jogo Deus Ex - Mankind Divided" /></figure>
                  <h3><span class="blu">R$</span> 49,99</h3>
                  <p>Deus Ex - Mankind Divided - xbox one</p>
                  <h2 class="read_more">Disponível</h2>
               </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
               <div class="glasses_box">
                  <figure><img src="jogosplay/finalfantasy.jpg" alt="jogo final fantasy" /></figure>
                  <h3><span class="blu">R$</span> 239,99</h3>
                  <p>Final Fantasy XVI - playstation 5</p>
                  <h2 class="read_more">Disponível</h2>
               </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
               <div class="glasses_box">
                  <figure><img src="jogosxbox/farcry5.jpg" alt="jogo far cry 5" /></figure>
                  <h3><span class="blu">R$</span> 49,99</h3>
                  <p> Far Cry 5 - xbox one</p>
                  <h2 class="read_more">Disponível</h2>
               </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
               <div class="glasses_box">
                  <figure><img src="jogosplay/ghostoftsushima.jpg" alt="jogo ghost of tsushima" /></figure>
                  <h3><span class="blu">R$</span> 319,99</h3>
                  <p>Ghost Of Tsushima - playstation 5</p>
                  <h2 class="read_more">Disponível</h2>
               </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
               <div class="glasses_box">
                  <figure><img src="jogosxbox/harrypotterlego.jpg" alt="jogo harry potter lego" /></figure>
                  <h3><span class="blu">R$</span> 89,99</h3>
                  <p>Coleção Lego Harry Potter - xbox one</p>
                  <h2 class="read_more">Disponível</h2>
               </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
               <div class="glasses_box">
                  <figure><img src="jogosplay/godofwar.jpg" alt="jogo god of War" /></figure>
                  <h3><span class="blu">R$</span> </h3>
                  <p>God Of War Ragnarok - playstation 5</p>
                  <h2 class="read_more">Disponível</h2>
               </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
               <div class="glasses_box">
                  <figure><img src="jogosxbox/legomovie.jpg" alt="jogo the movie " /></figure>
                  <h3><span class="blu">R$</span> 49,99</h3>
                  <p>Lego The Movie</p>
                  <h2 class="read_more">Disponível</h2>
               </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
               <div class="glasses_box">
                  <figure><img src="jogosplay/granturismo.jpg" alt="jogo gran turismo" /></figure>
                  <h3><span class="blu">R$</span> 329,99</h3>
                  <p>Gran Turismo 7</p>
                  <h2 class="read_more">Disponível</h2>
               </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
               <div class="glasses_box">
                  <figure><img src="jogosxbox/narutostorm4.jpg" alt="jogo naruto storm 4" /></figure>
                  <h3><span class="blu">R$</span> 69,99</h3>
                  <p>Naruto Shippuden Ultimate Ninja Storm 4 Estrada para Boruto - xbox one</p>
                  <h2 class="read_more">Disponível</h2>
               </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
               <div class="glasses_box">
                  <figure><img src="jogosplay/gtaV.jpg" alt="jogo GTAV" /></figure>
                  <h3><span class="blu">R$</span> 99,99</h3>
                  <p>GTA 5 Grand Theft Auto V - playstation 5</p>
                  <h2 class="read_more">Disponível</h2>
               </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
               <div class="glasses_box">
                  <figure><img src="jogosxbox/nfsheat.jpg" alt="jogo Need For Speed NFS Sheat" /></figure>
                  <h3><span class="blu">R$</span> 79,99</h3>
                  <p>Need For Speed NFS Sheat - xbox one</p>
                  <h2 class="read_more">Disponível</h2>
               </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
               <div class="glasses_box">
                  <figure><img src="jogosplay/hogwartslegacy.jpg" alt="jogo hogwarts legacy" /></figure>
                  <h3><span class="blu">R$</span> 299,99</h3>
                  <p>hogwarts Legacy - playstation 5</p>
                  <h2 class="read_more">Disponível</h2>
               </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
               <div class="glasses_box">
                  <figure><img src="jogosxbox/rainbowsixsiege.jpg" alt="jogo rainbow sixiege" /></figure>
                  <h3><span class="blu">R$</span> 49,99</h3>
                  <p>Tom Clancy S Rainbow Six Siege - xbox one</p>
                  <h2 class="read_more">Disponível</h2>
               </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
               <div class="glasses_box">
                  <figure><img src="jogosplay/homemaranha2.jpg" alt="jogo homem aranha 2" /></figure>
                  <h3><span class="blu">R$</span> 279,99</h3>
                  <p>Marvel's Spider Man 2 - playstation 5</p>
                  <h2 class="read_more">Disponível</h2>
               </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
               <div class="glasses_box">
                  <figure><img src="jogosxbox/rocketarena.jpg" alt="jogo rocket arena" /></figure>
                  <h3><span class="blu">R$</span> 49,99</h3>
                  <p>Rocket Arena - xbox one</p>
                  <h2 class="read_more">Disponível</h2>
               </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
               <div class="glasses_box">
                  <figure><img src="jogosplay/ratchetclank.jpg" alt="jogo Ratchet & Clank" /></figure>
                  <h3><span class="blu">R$</span> 339,99</h3>
                  <p>Ratchet & Clank - playstation 5</p>
                  <h2 class="read_more">Disponível</h2>
               </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
               <div class="glasses_box">
                  <figure><img src="jogosxbox/screamride.jpg" alt="jogo screamride" /></figure>
                  <h3><span class="blu">R$</span> 49,99</h3>
                  <p>Screamride - xbox one</p>
                  <h2 class="read_more">Disponível</h2>
               </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
               <div class="glasses_box">
                  <figure><img src="jogosplay/stellarblade.jpg" alt="jogo stellarblade" /></figure>
                  <h3><span class="blu">R$</span> 249,99</h3>
                  <p>Stellar Blade - playstation 5</p>
                  <h2 class="read_more">Disponível</h2>
               </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
               <div class="glasses_box">
                  <figure><img src="jogosxbox/starwarsjedi.jpg" alt="jogo star wars jedi" /></figure>
                  <h3><span class="blu">R$</span> 49,99</h3>
                  <p>Star Wars Jedi - Ordem Caída - xbox one</p>
                  <h2 class="read_more">Disponível</h2>
               </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
               <div class="glasses_box">
                  <figure><img src="jogosplay/stray.jpg" alt="jogo stray" /></figure>
                  <h3><span class="blu">R$</span> 169,99</h3>
                  <p>Stray - playstation 5</p>
                  <h2 class="read_more">Disponível</h2>
               </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
               <div class="glasses_box">
                  <figure><img src="jogosxbox/thequarry.jpg" alt="jogo the quarry" /></figure>
                  <h3><span class="blu">R$</span> 79,99</h3>
                  <p>The Quarry</p>
                  <h2 class="read_more">Disponível</h2>
               </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
               <div class="glasses_box">
                  <figure><img src="jogosplay/thelastofus.jpg" alt="jogo the last of us" /></figure>
                  <h3><span class="blu">R$</span> 299,99</h3>
                  <p>The Last Of Us Parta I - Playstation 5</p>
                  <h2 class="read_more">Disponível</h2>
               </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
               <div class="glasses_box">
                  <figure><img src="jogosxbox/thewitcher.jpg" alt="jogo the witcher" /></figure>
                  <h3><span class="blu">R$</span> 109,99</h3>
                  <p>The Witcher 3 - Edição Completa - xbox one</p>
                  <h2 class="read_more">Disponível</h2>
               </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
               <div class="glasses_box">
                  <figure><img src="jogosplay/thelastofus2.jpg" alt="jogo the last of us 2" /></figure>
                  <h3><span class="blu">R$</span> 219,99</h3>
                  <p>The Last Of Us Parte II Remastered - playstation 5</p>
                  <h2 class="read_more">Disponível</h2>
               </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
               <div class="glasses_box">
                  <figure><img src="jogosxbox/ufc3.jpg" alt="jogo ufc 3" /></figure>
                  <h3><span class="blu">R$</span> 59,99</h3>
                  <p>EA Sports UFC 3 - xbox one</p>
                  <h2 class="read_more">Disponível</h2>
               </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
               <div class="glasses_box">
                  <figure><img src="produtos-perifericos/controle playstation 5 fortnite.jpg" alt="controle playstation 5 fortnite" /></figure>
                  <h3><span class="blu">R$</span> 359,99</h3>
                  <p>controle playstation 5 DualSense - Fortnite</p>
                  <h2 class="read_more">Disponível</h2>
               </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
               <div class="glasses_box">
                  <figure><img src="produtos-perifericos/controle playstation 5 vinho.jpg" alt="controle playstation 5 vinho" /></figure>
                  <h3><span class="blu">R$</span> 419,99</h3>
                  <p>controle playstation 5 DualSense - vinho</p>
                  <h2 class="read_more">Disponível</h2>
               </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
               <div class="glasses_box">
                  <figure><img src="produtos-perifericos/controle playstation 5 black.png" alt="controle playstation 5 black" /></figure>
                  <h3><span class="blu">R$</span> 389,99</h3>
                  <p>Controle playstation 5 DualSense - black</p>
                  <h2 class="read_more">Disponível</h2>
               </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
               <div class="glasses_box">
                  <figure><img src="produtos-perifericos/controle playstation 5 branco.jpg" alt="controle playstation 5 branco" /></figure>
                  <h3><span class="blu">R$</span> 389,99</h3>
                  <p>Controle playstation 5 DualSense - white</p>
                  <h2 class="read_more">Disponível</h2>
               </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
               <div class="glasses_box">
                  <figure><img src="produtos-perifericos/controle playstation 5 camuflado.jpg" alt="controle playstation 5 camuflado" /></figure>
                  <h3><span class="blu">R$</span> 409,99</h3>
                  <p>Controle playstation 5 DualSense - camuflado</p>
                  <h2 class="read_more">Disponível</h2>
               </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
               <div class="glasses_box">
                  <figure><img src="produtos-perifericos/controle xbox blue.png" alt="controle xbox blue" /></figure>
                  <h3><span class="blu">R$</span> 389,99</h3>
                  <p>Controle xbox series s - blue</p>
                  <h2 class="read_more">Disponível</h2>
               </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
               <div class="glasses_box">
                  <figure><img src="produtos-perifericos/controle xbox branco.jpg" alt="controle xbox branco" /></figure>
                  <h3><span class="blu">R$</span> 379,99</h3>
                  <p>Controle xbox series s - white</p>
                  <h2 class="read_more">Disponível</h2>
               </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
               <div class="glasses_box">
                  <figure><img src="produtos-perifericos/controle xbox larange.png" alt="controle xbox larange" /></figure>
                  <h3><span class="blu">R$</span> 449,99</h3>
                  <p>Controle xbox series s - larange</p>
                  <h2 class="read_more">Disponível</h2>
               </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
               <div class="glasses_box">
                  <figure><img src="produtos-perifericos/controle xbox rosa.png" alt="controle xbox rosa" /></figure>
                  <h3><span class="blu">R$</span> 419,99</h3>
                  <p>Controle xbox series s - rosa</p>
                  <h2 class="read_more">Disponível</h2>
               </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
               <div class="glasses_box">
                  <figure><img src="produtos-perifericos/controle xbox bege.png" alt="Controle xbox bege" /></figure>
                  <h3><span class="blu">R$</span> 339,99</h3>
                  <p>Controle xbox series s - bege</p>
                  <h2 class="read_more">Disponível</h2>
               </div>
            <div class="col-md-12">
               <a class="read_more" href="#"><img src="images/arrow.png" alt="seta que faz subir a página para cima"></a>
            </div>
         </div>
      </div>
   </div>
   <footer>
      <div class="footer">
         <div class="container">
            <div class="row">
               <div class="col-md-8 offset-md-2">
                  <ul class="location_icon">
                     <li><a href="https://maps.app.goo.gl/mvAChRx4Qs8vrUDn9"><i class="fa fa-map-marker"
                              aria-hidden="true"></i></a><br>Localização</li>
                     <li><a href="#"><i class="fa fa-phone" aria-hidden="true"></i></a><br> +01 1234567890</li>
                     <li><a href="#"><i class="fa fa-envelope" aria-hidden="true"></i></a><br> demo@gmail.com</li>
                  </ul>
               </div>
            </div>
         </div>
         <div class="copyright">
            <div class="container">
               <div class="row">
                  <div class="col-md-12">
                     <p>NOVOS GAMES COMERCIO VAREJISTA DE JOGOS - CPJ: 12.345.678/9101-12 :copyright: Todos os direitos
                        reservados. <br>2024 System TI Games v1.0</p>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </footer>
   <script src="js/jquery.min.js"></script>
   <script src="js/popper.min.js"></script>
   <script src="js/bootstrap.bundle.min.js"></script>
   <script src="js/jquery-3.0.0.min.js"></script>
   <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
   <script src="js/custom.js"></script>
</body>

</html>