<?php
require 'conexao.php';
session_start();

if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $produto_id = $_POST['produto_id'];
    $quantidade_vendida = $_POST['quantidade'];
    $forma_pagamento = $_POST['forma_pagamento'];

    // Verifica se o produto existe e se há quantidade suficiente em estoque
    $stmt = $pdo->prepare("SELECT preco, quantidade FROM produtos WHERE id = :produto_id");
    $stmt->execute([':produto_id' => $produto_id]);
    $produto = $stmt->fetch();

    if ($produto) {
        if ($produto['quantidade'] >= $quantidade_vendida) {
            // Calcula o total da venda
            $total = $produto['preco'] * $quantidade_vendida;

            // Registra a venda
            $stmt = $pdo->prepare("INSERT INTO vendas (usuario_id, produto_id, quantidade, forma_pagamento, total, data_venda) 
                                   VALUES (:usuario_id, :produto_id, :quantidade, :forma_pagamento, :total, NOW())");
            $stmt->execute([
                ':usuario_id' => $_SESSION['usuario_id'],
                ':produto_id' => $produto_id,
                ':quantidade' => $quantidade_vendida,
                ':forma_pagamento' => $forma_pagamento,
                ':total' => $total
            ]);

            // Subtrai a quantidade vendida do estoque
            $novo_estoque = $produto['quantidade'] - $quantidade_vendida;
            $stmt = $pdo->prepare("UPDATE produtos SET quantidade = :novo_estoque WHERE id = :produto_id");
            $stmt->execute([':novo_estoque' => $novo_estoque, ':produto_id' => $produto_id]);

            echo "Venda realizada com sucesso! Total: R$" . number_format($total, 2, ',', '.') . "<br>";
            echo "Estoque atualizado. Quantidade restante: " . $novo_estoque;
        } else {
            echo "Erro: Quantidade insuficiente em estoque!";
        }
    } else {
        echo "Produto não encontrado!";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vendas do produto</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #4c4e87;
            color: #fff;
            padding: 20px;
            text-align: center;
        }

        main {
            padding: 20px;
        }

        footer {
            background-color: #4c4e87;
            color: #fff;
            text-align: center;
            padding: 10px;
            position: fixed;
            width: 100%;
            bottom: 0;
        }

        form {
            margin-bottom: 20px;
        }

        form input,
        form select {
            margin-bottom: 10px;
            padding: 5px;
            width: 100%;
        }

        form button {
            padding: 10px;
            background-color: #4c4e87;
            color: white;
            border: none;
            cursor: pointer;
        }

        form button:hover {
            background-color: #4c4e87;
        }
    </style>
</head>

<body>
    <form method="POST">
        <label for="produto">Produto: </label>
        <select name="produto_id" id="produto">
            <?php
            $stmt = $pdo->query("SELECT id, nome FROM produtos");
            while ($produto = $stmt->fetch(PDO::FETCH_ASSOC)) {
                echo "<option value='" . $produto['id'] . "'>" . htmlspecialchars($produto['nome']) . "</option>";
            }
            ?>
        </select><br>
        <label for="quantidade">Quantidade: </label>
        <input type="number" name="quantidade" id="quantidade" required><br>
        <h2>Forma de Pagamento: </h2>
        <select name="forma_pagamento" id="formapagamento">
            <option value="Cartão" id="formapagamento">Cartão</option>
            <option value="Dinheiro" id="formapagamento">Dinheiro</option>
        </select><br>
        <button type="submit">Finalizar Venda</button>
        <p><a href="dashboard_funcionario.php">Voltar para o perfil</a></p>
    </form>
</body>

</html>